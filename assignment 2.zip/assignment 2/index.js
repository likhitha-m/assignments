const express = require("express");
const bodyparser = require("body-parser");
const app = express();

app.use(bodyparser());

app.get('/', function (req, res) {
    res.send({ message: 'result from GET request' })
});

app.post('/', function (req, res) {
    console.log(req.body)
    if (!req.body.name) {
        res.send({ code: 400, message: 'Parameter missing : name' })
    }
    else if (!req.body.email) {
        res.send({ code: 400, message: 'Invalid params email' });
    } else {
        res.send({ message: 'data created' })
    }


});
app.listen(8000, function (req, res) {
    console.log("listening to port 8000")
})

