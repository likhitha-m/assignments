const fs = require("fs");
fs.readFile('./output/input.txt', 'utf8', function (err, data) {
    if (!err || data) {
        fs.writeFile('./output/output.txt', data, 'utf8', function (err, data) {
            console.log("err", err, data)
        })
    } else {
        console.log("err", err)
    }
})
